package com.wing.stormv32;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class FeatureActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_feature);

        // 返回按钮
        ImageView backBtn = findViewById(R.id.iv_back);
        backBtn.setOnClickListener(v -> finish());
    }
}
