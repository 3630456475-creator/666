package com.wing.stormv32;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;

public class TutorialActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tutorial);

        // 返回按钮
        ImageView backBtn = findViewById(R.id.iv_back);
        backBtn.setOnClickListener(v -> finish());
    }
}
