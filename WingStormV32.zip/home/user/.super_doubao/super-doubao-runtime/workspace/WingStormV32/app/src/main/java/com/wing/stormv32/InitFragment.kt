package com.wing.stormv32

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment

class InitFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_init, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Shizuku授权开关
        view.findViewById<android.widget.Switch>(R.id.switch_shizuku).setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                Toast.makeText(requireContext(), "正在请求Shizuku授权...", Toast.LENGTH_SHORT).show()
                // 这里可以添加实际的Shizuku授权逻辑
            } else {
                Toast.makeText(requireContext(), "已取消Shizuku授权", Toast.LENGTH_SHORT).show()
            }
        }

        // 下载配置资源包开关
        view.findViewById<android.widget.Switch>(R.id.switch_download).setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                Toast.makeText(requireContext(), "开始下载配置资源包...", Toast.LENGTH_SHORT).show()
                // 这里可以添加实际的下载逻辑
            } else {
                Toast.makeText(requireContext(), "已取消下载", Toast.LENGTH_SHORT).show()
            }
        }

        // 初始化注入配置开关
        view.findViewById<android.widget.Switch>(R.id.switch_inject).setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                Toast.makeText(requireContext(), "正在初始化注入配置...", Toast.LENGTH_SHORT).show()
                // 这里可以添加实际的注入逻辑
            } else {
                Toast.makeText(requireContext(), "已取消注入", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
