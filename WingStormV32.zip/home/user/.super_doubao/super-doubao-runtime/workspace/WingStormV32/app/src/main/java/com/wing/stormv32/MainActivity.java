package com.wing.stormv32;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private static final int REQUEST_STORAGE_PERMISSION = 1001;
    private static final int REQUEST_FLOAT_WINDOW = 1002;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 初始化按钮
        Button btnFloatWindow = findViewById(R.id.btn_float_window);
        Button btnShizuku = findViewById(R.id.btn_shizuku);
        Button btnIntro = findViewById(R.id.btn_intro);
        Button btnTutorial = findViewById(R.id.btn_tutorial);

        // 申请存储权限
        requestStoragePermission();

        // 开启悬浮窗按钮
        btnFloatWindow.setOnClickListener(v -> {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                if (!Settings.canDrawOverlays(this)) {
                    Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:" + getPackageName()));
                    startActivityForResult(intent, REQUEST_FLOAT_WINDOW);
                } else {
                    Toast.makeText(this, "悬浮窗权限已开启", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // 授权Shizuku按钮
        btnShizuku.setOnClickListener(v -> {
            try {
                Intent intent = getPackageManager().getLaunchIntentForPackage("moe.shizuku.privileged.api");
                if (intent != null) {
                    startActivity(intent);
                } else {
                    Toast.makeText(this, "请先安装Shizuku应用", Toast.LENGTH_SHORT).show();
                    // 跳转到应用商店
                    Intent marketIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=moe.shizuku.privileged.api"));
                    startActivity(marketIntent);
                }
            } catch (Exception e) {
                Toast.makeText(this, "无法打开Shizuku，请手动打开", Toast.LENGTH_SHORT).show();
            }
        });

        // 功能介绍按钮
        btnIntro.setOnClickListener(v -> {
            new AlertDialog.Builder(this)
                    .setTitle("功能介绍")
                    .setMessage("Wing暴风雪V32是一款多功能工具应用：\n\n1. 悬浮窗功能：提供全局悬浮操作按钮\n2. Shizuku授权：通过Shizuku获取高级权限\n3. 更多功能持续更新中...")
                    .setPositiveButton("确定", null)
                    .show();
        });

        // 查看教程按钮
        btnTutorial.setOnClickListener(v -> {
            new AlertDialog.Builder(this)
                    .setTitle("使用教程")
                    .setMessage("使用步骤：\n\n1. 先点击「授权shizuku」，打开Shizuku并完成授权\n2. 点击「开启悬浮窗」，授予悬浮窗权限\n3. 授权完成后即可使用所有功能\n\n注意：使用前请确保已安装Shizuku应用并正确配置。")
                    .setPositiveButton("确定", null)
                    .show();
        });
    }

    // 申请存储权限
    private void requestStoragePermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            String[] permissions = {
                    android.Manifest.permission.READ_MEDIA_IMAGES,
                    android.Manifest.permission.READ_MEDIA_VIDEO,
                    android.Manifest.permission.READ_MEDIA_AUDIO
            };
            ActivityCompat.requestPermissions(this, permissions, REQUEST_STORAGE_PERMISSION);
        } else {
            String[] permissions = {
                    android.Manifest.permission.READ_EXTERNAL_STORAGE,
                    android.Manifest.permission.WRITE_EXTERNAL_STORAGE
            };
            ActivityCompat.requestPermissions(this, permissions, REQUEST_STORAGE_PERMISSION);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_FLOAT_WINDOW) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                if (Settings.canDrawOverlays(this)) {
                    Toast.makeText(this, "悬浮窗权限开启成功", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "悬浮窗权限开启失败", Toast.LENGTH_SHORT).show();
                }
            }
        }
    }
}
