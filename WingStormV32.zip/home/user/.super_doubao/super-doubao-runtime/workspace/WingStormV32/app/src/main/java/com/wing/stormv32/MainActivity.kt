package com.wing.stormv32

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.drawerlayout.widget.DrawerLayout
import com.google.android.material.navigation.NavigationView

class MainActivity : AppCompatActivity() {

    private lateinit var drawerLayout: DrawerLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        drawerLayout = findViewById(R.id.drawer_layout)
        val navView: NavigationView = findViewById(R.id.nav_view)

        // 按钮点击事件
        findViewById<android.widget.Button>(R.id.btn_float_window).setOnClickListener {
            checkFloatWindowPermission()
        }

        findViewById<android.widget.Button>(R.id.btn_shizuku).setOnClickListener {
            openShizukuAuth()
        }

        findViewById<android.widget.Button>(R.id.btn_feature).setOnClickListener {
            Toast.makeText(this, "功能介绍：本工具提供Shizuku授权、悬浮窗辅助、游戏配置注入等功能", Toast.LENGTH_LONG).show()
        }

        findViewById<android.widget.Button>(R.id.btn_tutorial).setOnClickListener {
            Toast.makeText(this, "使用教程：1. 先安装Shizuku并授权 2. 开启悬浮窗权限 3. 下载配置资源包 4. 初始化注入", Toast.LENGTH_LONG).show()
        }

        // 侧边栏菜单点击
        navView.setNavigationItemSelectedListener { menuItem ->
            when (menuItem.itemId) {
                R.id.nav_home -> {
                    // 返回主页
                    drawerLayout.closeDrawers()
                }
                R.id.nav_init -> {
                    // 显示初始配置页面
                    supportFragmentManager.beginTransaction()
                        .replace(android.R.id.content, InitFragment())
                        .commit()
                    drawerLayout.closeDrawers()
                }
                R.id.nav_function -> {
                    Toast.makeText(this, "功能页面开发中", Toast.LENGTH_SHORT).show()
                    drawerLayout.closeDrawers()
                }
                R.id.nav_music -> {
                    Toast.makeText(this, "音乐功能开发中", Toast.LENGTH_SHORT).show()
                    drawerLayout.closeDrawers()
                }
                R.id.nav_setting -> {
                    Toast.makeText(this, "设置页面开发中", Toast.LENGTH_SHORT).show()
                    drawerLayout.closeDrawers()
                }
            }
            true
        }
    }

    // 检查悬浮窗权限
    private fun checkFloatWindowPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (!Settings.canDrawOverlays(this)) {
                val intent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
                startActivityForResult(intent, 1001)
            } else {
                Toast.makeText(this, "悬浮窗权限已开启", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // 打开Shizuku授权
    private fun openShizukuAuth() {
        try {
            val intent = packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")
            if (intent != null) {
                startActivity(intent)
            } else {
                Toast.makeText(this, "请先安装Shizuku应用", Toast.LENGTH_LONG).show()
                // 跳转到应用商店下载
                val marketIntent = Intent(Intent.ACTION_VIEW)
                marketIntent.data = Uri.parse("market://details?id=moe.shizuku.privileged.api")
                startActivity(marketIntent)
            }
        } catch (e: Exception) {
            Toast.makeText(this, "打开Shizuku失败，请手动打开", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1001) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                if (Settings.canDrawOverlays(this)) {
                    Toast.makeText(this, "悬浮窗权限开启成功", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "悬浮窗权限开启失败", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
}
